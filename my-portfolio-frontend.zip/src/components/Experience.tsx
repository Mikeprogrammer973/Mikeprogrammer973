'use client'
import { experience } from '@/data/experience'

export default function Experience(){
  return (
    <section id="experience" className="py-20 px-6">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-8"><span className="text-accent">#</span> Experience</h2>
        <div className="space-y-6">
          {experience.map((e,i)=> (
            <div key={i} className="p-4 bg-panel/60 border border-accent/8 rounded">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-semibold">{e.role} — <span className="text-gray-300">{e.company}</span></h3>
                <span className="text-sm text-gray-400">{e.date}</span>
              </div>
              <p className="text-gray-300 text-sm">{e.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
