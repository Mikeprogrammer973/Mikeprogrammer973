'use client'
import { useEffect, useState } from 'react'

export default function AnimatedBackground(){
  const [bars, setBars] = useState<number[]>([])
  useEffect(()=> setBars(Array.from({length: 28}, (_,i)=>i)), [])

  return (
    <div aria-hidden className="absolute inset-0 -z-10 overflow-hidden">
      {bars.map(i => {
        const left = Math.random() * 100
        const delay = Math.random() * 6
        const duration = 6 + Math.random() * 9
        const height = 60 + Math.random() * 180
        const opacity = 0.05 + Math.random() * 0.14
        const style: React.CSSProperties = {
          left: `${left}%`,
          top: `${-40 - Math.random()*80}px`,
          height: `${height}px`,
          opacity,
          animationDelay: `${delay}s`,
          animationDuration: `${duration}s`,
          animationName: 'fall',
          animationTimingFunction: 'linear',
          animationIterationCount: 'infinite'
        }
        return <span key={i} style={style} className="absolute w-[2px] bg-accent/30 rounded" />
      })}

      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#00000010] to-[#00000090] pointer-events-none" />
    </div>
  )
}
