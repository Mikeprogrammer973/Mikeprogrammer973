'use client'
import Link from 'next/link'
import { useState } from 'react'
import { HiOutlineMenu, HiOutlineX } from 'react-icons/hi'
import { motion } from 'framer-motion'

const links = [
  { name: 'home', href: '#home' },
  { name: 'about', href: '#about' },
  { name: 'experience', href: '#experience' },
  { name: 'projects', href: '#projects' },
  { name: 'contact', href: '#contact' }
]

export default function Navbar(){
  const [open, setOpen] = useState(false)
  return (
    <nav className="fixed top-0 left-0 w-full z-50 bg-[#0D1117]/60 backdrop-blur-sm border-b border-[#111827]/10">
      <div className="max-w-6xl mx-auto flex items-center justify-between px-6 py-3">
        <div className="flex items-center gap-4">
          <div className="text-accent font-bold text-lg" aria-hidden>&lt;Mike /&gt;</div>
        </div>

        <ul className="hidden md:flex gap-6 text-gray-300 text-sm select-none">
          {links.map((l,i)=> (
            <motion.li key={i} whileHover={{ scale:1.04, color: 'var(--accent)' }} className="capitalize">
              <Link href={l.href} scroll={false}>{l.name}</Link>
            </motion.li>
          ))}
        </ul>

        <div className="hidden md:flex items-center gap-4">
          <a href="/resume.pdf" target="_blank" rel="noreferrer" className="border px-3 py-1 rounded border-accent text-accent hover:bg-accent hover:text-black transition">Resume</a>
        </div>

        {/* mobile */}
        <div className="md:hidden">
          <button aria-label="menu" onClick={()=> setOpen(v=>!v)} className="p-2 rounded bg-[#0D1117]/20">
            {open ? <HiOutlineX size={22}/> : <HiOutlineMenu size={22}/>}
          </button>
        </div>
      </div>

      {/* mobile menu */}
      {open && (
        <div className="md:hidden bg-[#081018]/90 border-t border-[#111827]/10">
          <div className="px-6 py-4 flex flex-col gap-3">
            {links.map((l,i)=> (
              <Link key={i} href={l.href} scroll={false} onClick={()=> setOpen(false)} className="text-gray-200 capitalize py-2 border-b border-[#111827]/5">
                {l.name}
              </Link>
            ))}
            <a href="/resume.pdf" className="mt-2 inline-block px-4 py-2 border border-accent text-accent rounded">Resume</a>
          </div>
        </div>
      )}
    </nav>
  )
}
