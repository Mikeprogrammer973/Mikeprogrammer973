'use client'
import { projects } from '@/data/projects'
import { motion } from 'framer-motion'
import Image from 'next/image'

export default function Projects(){
  return (
    <section id="projects" className="py-20 px-6">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-8"><span className="text-accent">#</span> Projects</h2>
        <div className="grid gap-6 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
          {projects.map((p,i)=> (
            <motion.article key={i} initial={{opacity:0,y:30}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{delay:i*0.06}} className="bg-soft/80 border border-[#3c3c3c] rounded-lg p-0 overflow-hidden hover:scale-[1.015] transition-transform card-glow">
              <div className="relative w-full h-44 md:h-40 lg:h-44">
                <Image src={p.image} alt={p.title} fill style={{objectFit:'cover'}} sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw" />
              </div>
              <div className="p-5">
                <h3 className="text-accent font-semibold mb-2">{p.title}</h3>
                <p className="text-gray-300 mb-4">{p.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">{p.tags.map(t=> <span key={t} className="text-xs bg-[#2d2d2d] px-2 py-1 rounded">{t}</span>)}</div>
                <div className="flex gap-3">
                  <a href={p.demo} className="text-blue-400 text-sm hover:underline">Live</a>
                  <a href={p.github} className="text-blue-400 text-sm hover:underline">GitHub</a>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  )
}
