'use client'
import { motion } from 'framer-motion'
import Terminal from './Terminal'

export default function Hero(){
  return (
    <section id="home" className="relative flex flex-col items-center justify-center h-screen text-center px-4">
      <motion.h1 initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} transition={{duration:0.6}} className="text-4xl md:text-6xl font-bold mb-4 leading-tight">
        Hi, I'm <span className="text-accent">Mike Pascal</span>
      </motion.h1>

      <motion.p initial={{opacity:0}} animate={{opacity:1}} transition={{delay:0.2}} className="text-gray-400 max-w-2xl">
        I build beautiful, responsive, and interactive experiences on the web.
      </motion.p>

      <Terminal />

      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10">
        <a href="#projects" className="animate-bounce text-gray-300">↓</a>
      </div>
    </section>
  )
}
