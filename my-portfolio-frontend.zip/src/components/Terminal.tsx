'use client'
import { useEffect, useState } from 'react'

const commands = [
  'git clone https://github.com/mike/portfolio.git',
  'cd portfolio',
  'npm install',
  'npm run dev'
]

export default function Terminal(){
  const [idx, setIdx] = useState(0)
  const [typed, setTyped] = useState('')

  useEffect(()=>{
    let active = true
    const cur = commands[idx]
    if (typed.length < cur.length) {
      const t = setTimeout(()=> { if(active) setTyped(cur.slice(0, typed.length+1)) }, 36)
      return ()=> { active = false; clearTimeout(t) }
    } else {
      const wait = setTimeout(()=> {
        if(!active) return
        setIdx(i => (i+1) % commands.length)
        setTyped('')
      }, 900)
      return ()=> { active = false; clearTimeout(wait) }
    }
  }, [typed, idx])

  return (
    <div className="mt-8 w-full max-w-2xl mx-auto bg-panel border border-accent/10 rounded-lg shadow-accent">
      <div className="flex items-center gap-2 p-3 border-b border-accent/8">
        <span className="w-3 h-3 bg-red-500 rounded-full" />
        <span className="w-3 h-3 bg-yellow-400 rounded-full" />
        <span className="w-3 h-3 bg-accent rounded-full" />
      </div>
      <div className="p-4 font-mono text-accent text-sm">
        {`$ ${typed}`}<span className="caret">▋</span>
      </div>
    </div>
  )
}
