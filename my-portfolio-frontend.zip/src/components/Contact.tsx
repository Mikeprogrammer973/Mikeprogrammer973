'use client'
import { FaGithub, FaLinkedin, FaEnvelope } from 'react-icons/fa'

export default function Contact(){
  return (
    <section id="contact" className="py-16 px-6 bg-[#071019]">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-3xl font-bold mb-4"><span className="text-accent">#</span> Contact</h2>
        <p className="text-gray-300 mb-6">Want to work together? Reach out via email or LinkedIn.</p>
        <div className="flex items-center justify-center gap-6 text-2xl text-gray-300">
          <a href="#" aria-label="github"><FaGithub /></a>
          <a href="#" aria-label="linkedin"><FaLinkedin /></a>
          <a href="mailto:you@example.com" aria-label="email"><FaEnvelope /></a>
        </div>
      </div>
    </section>
  )
}
