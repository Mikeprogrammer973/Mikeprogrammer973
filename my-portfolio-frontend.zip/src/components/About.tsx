'use client'

export default function About(){
  return (
    <section id="about" className="py-20 px-6 bg-[#071019]">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold mb-4 text-center"><span className="text-accent">#</span> About</h2>
        <p className="text-gray-300 leading-relaxed mb-6">I'm a frontend dev focused on building pixel-perfect experiences. I love animations, ergonomics and clean components.</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {['React','TypeScript','Tailwind','Framer Motion','GSAP','Node'].map(s=> (
            <div key={s} className="bg-panel/60 border border-accent/8 p-3 rounded text-sm text-gray-200">{s}</div>
          ))}
        </div>
      </div>
    </section>
  )
}
