export const projects = [
  { title: 'Pac-Man Clone', description: 'Classic game recreated with Canvas & JS.', tags: ['JS','Canvas'], demo: '#', github: '#', image: '/assets/pacman.png' },
  { title: 'Festiva', description: 'Event platform with animations and microinteractions.', tags: ['React','Tailwind'], demo: '#', github: '#', image: '/assets/festiva.png' },
  { title: 'LinkedIn Post Generator', description: 'Generate optimized posts with templates.', tags: ['Node','API'], demo: '#', github: '#', image: '/assets/linkedin.png' },
  { title: 'Codeplayers', description: 'Responsive site redesign.', tags: ['HTML','CSS'], demo: '#', github: '#', image: '/assets/codeplayers.png' },
  { title: 'Design System', description: 'UI primitives & components library.', tags: ['Design','React'], demo: '#', github: '#', image: '/assets/designsystem.png' },
  { title: 'Mini Game', description: 'Fun interactive mini-game.', tags: ['Game','JS'], demo: '#', github: '#', image: '/assets/minigame.png' }
]
