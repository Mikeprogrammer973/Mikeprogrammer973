export const experience = [
  { company: 'Startup A', role: 'Frontend Engineer', date: '2023 - present', description: 'Designing great UI and interactions.' },
  { company: 'Agency B', role: 'UI Developer', date: '2021 - 2023', description: 'Built responsive websites and design systems.' }
]
