import Hero from '@/components/Hero'
import AnimatedBackground from '@/components/AnimatedBackground'
import About from '@/components/About'
import Experience from '@/components/Experience'
import Projects from '@/components/Projects'
import Contact from '@/components/Contact'
import Footer from '@/components/Footer'

export default function HomePage(){
  return (
    <main className="relative min-h-screen overflow-x-hidden">
      <AnimatedBackground />
      <Hero />
      <About />
      <Experience />
      <Projects />
      <Contact />
      <Footer />
    </main>
  )
}
