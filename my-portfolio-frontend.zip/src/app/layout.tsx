import './styles/globals.css'
import type { ReactNode } from 'react'
import Navbar from '@/components/Navbar'

export const metadata = {
  title: 'Mike Pascal — Frontend Developer',
}

export default function RootLayout({ children }: { children: ReactNode }){
  return (
    <html lang="en">
      <body className="scroll-smooth bg-bgDark">
        <Navbar />
        {children}
      </body>
    </html>
  )
}
